package com.cg.cinematic.exception;

public class HousefullException extends Throwable {
}
