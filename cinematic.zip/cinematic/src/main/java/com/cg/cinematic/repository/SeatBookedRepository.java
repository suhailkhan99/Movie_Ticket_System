package com.cg.cinematic.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.cinematic.model.SeatBooked;

public interface SeatBookedRepository extends JpaRepository<SeatBooked, Long> {
}
