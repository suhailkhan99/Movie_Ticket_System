package com.cg.cinematic.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.cinematic.model.Theatre;

public interface TheatreRepository extends JpaRepository<Theatre, Long> {
}
