package com.cg.cinematic.exception;

public class ScreeningNotFoundException extends RuntimeException {
}
