package com.cg.cinematic.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.cinematic.model.Screening;

import java.util.List;

public interface ScreeningRepository extends JpaRepository<Screening, Long> {}
