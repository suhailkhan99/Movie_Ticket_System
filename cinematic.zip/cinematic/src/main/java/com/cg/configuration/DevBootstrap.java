package com.cg.configuration;

public class DevBootstrap {
}
