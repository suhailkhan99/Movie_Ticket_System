# cinematic
A movie ticket booking system created using Spring Boot, Spring Data JPA/MySQL, Hibernate

## er model
https://www.lucidchart.com/invitations/accept/717b2a94-a3b8-44b6-b556-0c4b482b931c
